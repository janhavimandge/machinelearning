import re
import pandas as pd
from transformers import AutoTokenizer, AutoModel, pipeline

def find_links_in_text(text):
    url_pattern = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
    urls = re.findall(url_pattern, text)
    return urls
 
# Load the sentiment analysis pipeline
def preprocess(data):
    # pattern = r'\d{2}/\d{2}/\d{2}, \d{2}:\d{2}\s[ap]m - '

    # messages = re.split(pattern, data)[1:]

    # dates = re.findall(pattern, data)
    # print("################################")
    # print(data)
    # print(messages)
    # df = pd.DataFrame({'user_message': messages, 'message_date': dates})
    # convert message_date type
    # df['message_date'] = pd.to_datetime(df['message_date'], format='%d/%m/%Y, %H:%M - ')

    # df.rename(columns={'message_date': 'date'}, inplace=True)
    pattern = r'\d{2}/\d{2}/\d{2}, \d{2}:\d{2}\s[ap]m - '
    print("################################")
    print(data)
    # f = open(data, 'r', encoding='utf-8')
    # data = f.read()

    message = re.split(pattern, data)[1:]
    dates = re.findall(pattern, data)
    # here  we need to write a code for text summary 
    # print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
    # print(message)
    df = pd.DataFrame({'user_message': message, 'message_date': dates})
    df['message_date'] = pd.to_datetime(df['message_date'], format='%d/%m/%y, %H:%M %p - ')

    df.rename(columns={'message_date': 'date'}, inplace=True)
    
    
    nlp = pipeline("sentiment-analysis")
   
    users = []
    messages = []
    for message in df['user_message']:
        entry = re.split('([\w\W]+?):\s', message)
        if entry[1:]:  # user name
            users.append(entry[1])
            messages.append(" ".join(entry[2:]))
        else:
            users.append('group_notification')
            messages.append(entry[0])

    df['user'] = users
    df['message'] = messages 
    positiveScore =0
    nagativeScore =0
    positiveCount =0
    NagativeCount =0
    linkListInMeassage = []
    for msg in df['message']:
        result = nlp(msg) 
        linkList = find_links_in_text(msg)
        if len(linkList)!=0:
            for link in linkList:
                linkListInMeassage.append(link)
        if result[0]['label'] == 'POSITIVE':
            positiveScore = positiveScore+result[0]['score']
            positiveCount =positiveCount+1
        else:
            nagativeScore = nagativeScore+result[0]['score']
            NagativeCount = NagativeCount+1
    positiveScore = positiveScore/positiveCount
    nagativeScore = nagativeScore/NagativeCount
   
    df.drop(columns=['user_message'], inplace=True)

    df['only_date'] = df['date'].dt.date
    df['year'] = df['date'].dt.year
    df['month_num'] = df['date'].dt.month
    df['month'] = df['date'].dt.month_name()
    df['day'] = df['date'].dt.day
    df['day_name'] = df['date'].dt.day_name()
    df['hour'] = df['date'].dt.hour
    df['minute'] = df['date'].dt.minute

    period = []
    for hour in df[['day_name', 'hour']]['hour']:
        if hour == 23:
            period.append(str(hour) + "-" + str('00'))
        elif hour == 0:
            period.append(str('00') + "-" + str(hour + 1))
        else:
            period.append(str(hour) + "-" + str(hour + 1))

    df['period'] = period

    return df , positiveScore , nagativeScore , linkListInMeassage