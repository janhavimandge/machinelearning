
# import re
# import pandas as pd

# # pattern = r'\d{2}/\d{2}/\d{2}, \d{2}:\d{2}\s[ap]m - '

# # f = open('demo.txt','r',encoding='utf-8')
# # data = f.read()
# # # print(data) 

# # message = re.split(pattern,data)[1:]
# # print(len(message))
# # dates = re.findall(pattern,data)
# # print(len(dates))

# # df = pd.DataFrame({'user_message':message,'message_date':dates})
# # df['message_date'] = pd.to_datetime(df['message_date'], format='%d/%m/%Y, %H:%M - ')
# # df.rename(columns={'message_date':'date'},index=True)
# # print(df)
# # import re
# # import pandas as pd

# # pattern = r'\d{2}/\d{2}/\d{2}, \d{2}:\d{2}\s[ap]m - '

# # f = open('demo.txt', 'r', encoding='utf-8')
# # data = f.read()

# # message = re.split(pattern, data)[1:]
# # dates = re.findall(pattern, data)

# # df = pd.DataFrame({'user_message': message, 'message_date': dates})
# # df['message_date'] = pd.to_datetime(df['message_date'], format='%d/%m/%y, %H:%M %p - ')
# # df.rename(columns={'message_date': 'date'}, inplace=True)
# # print(df)


# from transformers import AutoTokenizer, AutoModel, pipeline
 
 
# # Load the sentiment analysis pipeline
# nlp = pipeline("sentiment-analysis")

# # Test the model
# print("*************")
# print(nlp("I don't love this!"))
# result = nlp("I love this!")[0]

# # Print the result
# print(f"label: {result['label']}, with score: {result['score']}")

# import re

# def find_links_in_text(text):
#     url_pattern = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
#     urls = re.findall(url_pattern, text)
#     return urls

# text = "Here is a link:  "
# print(find_links_in_text(text))

from transformers import pipeline
summarizer = pipeline("summarization", model="philschmid/bart-large-cnn-samsum")

conversation = '''Jeff: Can I train a 🤗 Transformers model on Amazon SageMaker? 
Philipp: Sure you can use the new Hugging Face Deep Learning Container. 
Jeff: ok.
Jeff: and how can I get started? 
Jeff: where can I find documentation? 
Philipp: ok, ok you can find everything here. https://huggingface.co/blog/the-partnership-amazon-sagemaker-and-hugging-face                                           
'''
summarizer(conversation)
